package com.springHibernate.dao;

import com.springHibernate.model.Employee;

public interface EmployeeDao {
	public void saveEmployee(Employee employee);
}
