package com.springHibernate.application;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springHibernate.configuration.JdbcConfig;
import com.springHibernate.dao.EmployeeDaoImpl;
import com.springHibernate.model.Address;
import com.springHibernate.model.Employee;

public class App {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(JdbcConfig.class);
		EmployeeDaoImpl dao = (EmployeeDaoImpl) context.getBean("employeeDaoImpl");

		Employee employee = new Employee();
		employee.setName("Asharudheen");
		employee.setSalary(50000f);

		Address address = new Address();
		address.setHouseName("Asharikandi house");
		address.setPhone("9846800398");

		employee.setAddress(address);
		address.setEmployee(employee);
		dao.saveEmployee(employee);
		System.out.println("Success");
	}

}
